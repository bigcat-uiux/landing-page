<section class="social">
  <nav>
    <a data-href="discord-link">
      <img data-src="discord-img" width="25" height="24" alt="Discord" loading="lazy">
    </a>
    <a data-href="facebook-link">
      <img data-src="facebook-img" width="25" height="24" alt="Facebook" loading="lazy">
    </a>
    <a data-href="instagram-link">
      <img data-src="instagram-img" width="25" height="24" alt="Instagram" loading="lazy">
    </a>
    <a data-href="twitter-link">
      <img data-src="twitter-img" width="25" height="24" alt="Twitter" loading="lazy">
    </a>
    <a data-href="youtube-link">
      <img data-src="youtube-img" width="25" height="24" alt="Youtube" loading="lazy">
    </a>
    <a data-href="twitch-link">
      <img data-src="twitch-img" width="25" height="24" alt="Twitch" loading="lazy">
    </a>
  </nav>
</section>