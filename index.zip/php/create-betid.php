<?php

/*
 * ==================================================================
 * Execute operations upon form submit (store form data in date.csv).
 * ==================================================================
 */
if (isset($_POST['submitBetIdForm'])) {
  // Collect the form data.
  $betId= isset($_POST['betId']) ? $_POST['betId'] : '';
  $m88username = isset($_POST['m88username']) ? $_POST['m88username'] : '';
  $recipient = isset($_POST['recipient']) ? $_POST['recipient'] : '';
  $contact = isset($_POST['contact']) ? $_POST['contact'] : '';
  $address = isset($_POST['address']) ? $_POST['address'] : '';
  $postal = isset($_POST['postal']) ? $_POST['postal'] : '';
  $remark = isset($_POST['remark']) ? $_POST['remark'] : '';

  // Check if first name is set.
  // if ($timestamp == '') {
  //     $errors[] = 'First name is required';
  // }

  // Check if last name is set.
  // if ($minigame == '') {
  //     $errors[] = 'Last name is required';
  // }

  // Validate the phone number.
  // $pattern = '/^(?:\(\+?44\)\s?|\+?44 ?)?(?:0|\(0\))?\s?(?:(?:1\d{3}|7[1-9]\d{2}|20\s?[78])\s?\d\s?\d{2}[ -]?\d{3}|2\d{2}\s?\d{3}[ -]?\d{4})$/';
  // if (!preg_match($pattern, $phone)) {
  //     $errors[] = 'Please enter a valid phone number';
  // }

  // If no errors carry on.
  if (!isset($errors)) {
    // The header row of the CSV.
    $header = "Timestamp,CNY Submission Form,M88 Username,Recipient,Contact,Address,Postal\n";
    // The data of the CSV.
    date_default_timezone_set('Asia/Manila');
    $data = date("Md-Y h:i:sA") . ",$betId,$m88username,$recipient,$contact,$address,$postal\n";

    header('Location: index.php#submitted');

    /*
         * The file name of the CSV.
         * 
         * NB: __DIR__ describes the location in which this file resides.
         * To go up one level use "dirname(__DIR__)".
         * 
         * NB: You will not be able to append data to an existing file if you use time components 
         * (hour, minutes, seconds) inside the file name. Imagine that you are creating a file 
         * right now, at 12:18:43 o'clock. Then the file will be named "formdata-09-01-18-12-38-43.csv".
         * One second later you will not be able to append data to it because the time will be "12:38:44".
         * Then a new file "formdata-09-01-18-12-38-44.csv" will be created.
         * 
         * I suggest using only the date whithout the time in the file name.
         * 
         * @todo Read the comment above!
         */
    // $fileName = dirname(__DIR__) . "/minigame-" . date("y-m-d") . ".csv";
    $fileName = dirname(__DIR__) . "/cnysubmittijiao.csv";

    /*
         * Create the CSV file.
         * If file exists, append the data to it. Otherwise create the file.
         */
    if (file_exists($fileName)) {
      // Add only data. The header is already added in the existing file.
      file_put_contents($fileName, $data, FILE_APPEND);
    } else {
      // Add CSV header and data.
      file_put_contents($fileName, $header . $data);
    }

  }
}
