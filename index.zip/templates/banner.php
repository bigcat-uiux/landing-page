<section class="banner prllx">

  <!-- backgrounds -->
  <div class="prllx__layer prllx__layer--8">
    <div class="prllx__layer__img prllx__layer__img--8"></div>
  </div>
  <div class="prllx__layer prllx__layer--1">
    <div class="prllx__layer__img prllx__layer__img--1"></div>
  </div>
  <!-- /backgrounds -->

  <div class="prllx__layer prllx__layer--2">
    <div class="prllx__layer__img prllx__layer__img--2"></div>
  </div>
  <div class="prllx__layer prllx__layer--2a">
    <div class="prllx__layer__img prllx__layer__img--2a"></div>
  </div>
  <div class="prllx__layer prllx__layer--2b">
    <div class="prllx__layer__img prllx__layer__img--2b"></div>
  </div>
  <div class="prllx__layer prllx__layer--2c">
    <div class="prllx__layer__img prllx__layer__img--2c"></div>
  </div>

  <div class="prllx__layer prllx__layer--3 prllx__layer--act">
    <div class="prllx__layer__img prllx__layer__img--3"></div>
  </div>

  <div class="prllx__layer prllx__layer--4 prllx__layer--act">
    <div class="prllx__layer__img prllx__layer__img--4"></div>
  </div>

  <div class="prllx__layer prllx__layer--5 prllx__layer--act">
    <div class="prllx__layer__img prllx__layer__img--5"></div>
  </div>

  <div class="prllx__layer prllx__layer--6">
    <div class="prllx__layer__img prllx__layer__img--6"></div>
  </div>

  <div class="prllx__layer prllx__layer--7 prllx__layer--act">
    <div class="prllx__layer__img prllx__layer__img--7"></div>
  </div>

  <div class="prllx__layer prllx__layer--9 prllx__layer--act">
    <div class="prllx__layer__img prllx__layer__img--9"></div>
  </div>

  <div id="particles-js"></div>

  <div class="prllx__layer prllx__layer--10 prllx__layer--act">
    <div class="prllx__layer__img prllx__layer__img--10"></div>
  </div>

  <div class="prllx__layer prllx__layer--11">
    <div class="prllx__layer__img prllx__layer__img--11"></div>
  </div>



  <div class="prllx__layer prllx__layer--over"></div>

  <div class="banner__content">
    <div class="inner">
      <h1 data-txt="banner-h1"></h1>

      <a data-href="join-link" class="btn btn--gold" data-txt="join"></a>
    </div>
  </div>



</section>