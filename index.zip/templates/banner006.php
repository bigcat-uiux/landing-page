<section class="prllx">
  <article class="prllx-bg-006">

  <div id="particles-js"></div>

    <div class="banner__content">
      <div class="inner">
        <!-- <h1 data-txt="banner-h1"></h1> -->

        <div class="flex--006-link">
          <a data-href="join-link" class="btn btn--gold" data-txt="join"></a>
          <a data-href="faceit-join-link" class="btn btn--gold" data-txt="join-faceit"></a>
        </div>
      </div>
    </div>

  </article>
</section>