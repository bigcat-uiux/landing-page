<section class="prllx">
  <article class="prllx-bg">

  <div id="particles-js"></div>

    <div class="banner__content">
      <div class="inner">
        <!-- <h1 data-txt="banner-h1"></h1> -->

        <a data-href="join-link" class="btn btn--gold" data-txt="join"></a>
      </div>
    </div>

  </article>
</section>