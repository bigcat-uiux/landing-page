<?php include 'templates/head.php'; ?>
<?php include 'templates/header.php'; ?>

<main class="content">

  <?php include 'templates/banner.php'; ?>

  <?php include 'templates/008tnc.php'; ?>

</main>

<?php include 'templates/footer.php'; ?>