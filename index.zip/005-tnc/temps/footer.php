<footer class="footer">
			<div class="inner">

        <?php include 'social.php'; ?>

        <p class="copy">©
          <script>
            var today = new Date();
            document.write(window.location.hostname.replace('www.', '') + ' ' + today.getFullYear());
          </script>
        </p>
			</div>
		</footer>

    <?php // echo $url; ?>
		
		<script src='../assets/js/jquery-3.6.0.min.js'></script>
    <script src='../assets/js/swiper-bundle.min.js'></script>
    <script src='../assets/js/particles.min.js'></script>
    <script src='../assets/js/particles-options.js'></script>
		<script src='../assets/js/script.js?v=2'></script>
	</body>
</html>