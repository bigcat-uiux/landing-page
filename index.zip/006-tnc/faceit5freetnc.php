<?php include 'temps/head.php'; ?>
<?php include 'temps/header.php'; ?>

<main class="content">

  <?php include '../templates/banner.php'; ?>
  
  <?php include 'temps/tnc.php'; ?>

</main>

<?php include 'temps/footer.php'; ?>