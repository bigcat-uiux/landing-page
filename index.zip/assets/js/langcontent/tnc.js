
const tncEN = /*html*/`
<li> This promotion is applicable to new M88 Mansion players from 01 April 2023 00:00:00 to 30 April 2023 23:59:00 (GMT+8).</li>
<li> New Players are eligible to receive 100% up to MYR 128 Freebet Bonus with 5X rollover in TC Lottery.</li>
<li> The bonus will be issued in TC Lottery upon verification of successful minimum deposit of MYR 30.</li>
<li> The Deposit + Bonus amount must be rolled over 5X in TC Lottery prior to the withdrawal of winnings.</li>
<li> The bonus rollover must be fulfilled within 7 days to prevent forfeiture of the bonus and winning amount. </li>
<li> Only TC Lottery games will count towards the rollover contribution. Click Here to see Included and Excluded game list.</li>
<li> The bonus cannot be used in conjunction with other M88 Mansion promotions.</li>
<li> Each bonus can only be claimed 1x during the promotion period.</li>
<li> Withdrawals will not be processed if the player still has an active rollover. Please contact Customer Service to arrange for a waiver of the rollover requirement.</li>
<li> M88 Mansion reserves the right to change, update, modify, or cancel this promotion anytime.</li>
<li> <a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.en-US"> General Terms & Conditions of Promotions apply.</a>. </li>
`;


const tncCN = /*html*/`
<p>果敢下单，尽情玩赏，尊享 100% 返还！<br><br></p>
<li> 此优惠面向所有中国 M88 会员。
<table>
  <tr>
    <th width="50%">活动时间 (GMT+8)</th>
  </tr>
  <tr>
    <td>2024 年 01 月 02 日 12:00:00 – 2024 年 01 月 31 日 23:59:59  				</td>
  </tr>
</table>
</li>
<li> 活动期间, 会员只需投注于足球或篮球任何赛事的 【早盘】 - 全场让分盘 / 全场大小盘 / 全场 1x2 / 全场获胜者,  即可获得 100% 【M体育+】免费投注金返还, 详情如下: 
<table>
  <tr>
    <th>体育限定</th>
    <th>盘口限定</th>
    <th>返还率</th>
    <th>最低负盈利金额</th>
    <th>免费投注金返还上限</th>
  </tr>
  <tr>
    <td>【足球】 或 【篮球】</td>
    <td>【早盘】：全场让分盘 / 全场大小盘 / 全场 1x2 / 全场获胜者</td>
    <td>100% </td>
    <td>200 元</td>
    <td>200 元</td>
  </tr>
</table>
<br>
<p><strong>举例</strong></p>
<p>例 1:<br> 会员 A 在足球或篮球赛事，单笔负盈利达 100 元 = 不符合资格</p>
<p>例 2:<br> 会员 B 在足球或篮球赛事，投注于滚球及单笔负盈利达 200 元 = 不符合资格</p>
<p>例 3:<br> 会员 C 在足球或篮球赛事，投注于早盘-全场让分盘，单笔负盈利达  200 元 = 返还 200 元</p>
<p>例 4:<br> 会员 D 在足球或篮球赛事，投注于早盘-全场大小盘，单笔负盈利达  300 元 = 返还 200 元</p>
</li>
<li> 会员可通过邮件方式：标题为【极致畅玩 尊享返还】 并发送您的 【用户名】 & 【投注单号】 至： <a href="mailto:m88promo@m88asia.com" target="_blank" class="tc--link">m88promo@m88asia.com</a> 参与或通过提供资料让在线客服协助参与即可。任何未完整填写资料的申请将不被受理。</li>
<li> 活动期间内，每位会员仅限申请一次 100% 【M体育+】投注金返还。 </li>
<li> 此优惠需要审核投注单号，经过审核后将派发奖金给首 500 名符合条件的会员，先到先得。</li>
<li> 此优惠仅计算“真钱投注”和已结算的合格投注。 所有平局/退款/拒绝/无效/取消的投注，以及赔率低于 1.50 的投注（马来赔率 0.50；香港赔率 0.50；印度赔率 -2.00）将不包括在有效合格投注和/或流水要求的计算中（如适用）。</li>
<li> 此优惠申请注单需投注于任何足球或篮球赛事的 【早盘】 - 全场让分盘 / 全场大小盘 / 全场 1x2 / 全场获胜者方符合申请资格。</li>
<li> 免费投注金仅限于【M体育+】 使用，不可直接提款。</li>
<li> 未使用投注金将在成功派发的 14 天后自动过期。</li>
<li> <a href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.zh-CN" class="tc--link" target="_blank"> 一般条款及规则应用于此优惠。</a> </li>
`;