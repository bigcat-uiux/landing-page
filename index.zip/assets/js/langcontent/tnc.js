const tncEN = /*html*/ `
<li>This promotion is applicable to first 500 new M88 Mansion members from 23 May 2024 00:00:00 to 31 May 2024 23:59:00 (GMT+8).</li>
<li>New Members are eligible to receive the USD 8 Freebet Bonus with 1x rollover in Casino Slots.</li>
<li>The bonus will be issued in Casino Slots upon verification of successful registration.</li>
<li>The Bonus amount must be rolled over 1x in Casino Slots and have minimum deposit USD 10 prior to the withdrawal of winnings.
Maximum withdrawal is capped at USD 100.</li>
<li>The bonus rollover must be fulfilled within 7 days to prevent forfeiture of the bonus and winning amount. </li>
<li>Only casino slot games will count towards wagering contribution. <a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/gameexclusion_list.en-US" target="_blank">Click Here</a> to see the Included and Excluded game list.</li>
<li>The bonus cannot be used in conjunction with other M88 Mansion promotions. Unless otherwise stated.</li>
<li>This bonus can only be claimed 1x during the promotion period.</li>
<li>Withdrawal will not be processed if you still have an active rollover. Please contact Customer Service for further assistance.</li>
<li>M88 Mansion reserves the right to change, update, modify, or cancel this promotion anytime.</li>
<li><a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.en-US" target="_blank">General Terms & Conditions of Promotions apply. </a></li>
<table>
    <thead>
        <tr>
            <th colspan="8">MIN DEPS</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>USD 10</td>
            <td>CNY 100</td>
            <td>MYR 30</td>
            <td>THB 100</td>
            <td>INR 200</td>
            <td>VND 200</td>
            <td>IDR 50</td>
            <td>KRW 10,000</td>
        </tr>
    </tbody>
</table>
<br>
<table>
    <thead>
        <tr>
            <th colspan="8">MAX BONUS</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>USD 8</td>
            <td>CNY 58</td>
            <td>MYR 38</td>
            <td>THB 280</td>
            <td>INR 600</td>
            <td>VND 188</td>
            <td>IDR 138</td>
            <td>KRW 10,888</td>
        </tr>
    </tbody>
</table>
<br>
<table>
    <thead>
        <tr>
            <th colspan="8">MAX WITHDRAW</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>USD 100</td>
            <td>CNY 1000</td>
            <td>MYR 300</td>
            <td>THB 1000</td>
            <td>INR 2000</td>
            <td>VND 2000</td>
            <td>IDR 500</td>
            <td>KRW 100,000</td>
        </tr>
    </tbody>
</table>
<br>
<h2><strong>PROMO MECHANIC</strong></h2><br>
<p>Exclusive for first 500 new member</p><br>
<p>Offer bonus free bet USD 8 in Casino slot with 1x RO</p><br>
<p>Min deposit before withdrawal USD 10</p><br>
<p>Max withdrawal USD 100 from winning amount</p><br>
<p>Rollover must be fulfilled within 7 days to prevent forfeiture of the bonus and winning amount. </p><br>
<p>Can only be claimed 1x during the promotion period.</p><br>
<p>Bonus cannot be used in conjunction with other M88 Mansion promotions</p><br>
`;

const tncID = /*html*/ `
<li>Promosi ini berlaku untuk 500 Member baru M88 Mansion mulai 23 Mei 2023 00:00:00 hingga 31 Mei 2023 23:59:00 (GMT+8).</li>
<li>Member Baru berhak menerima Bonus Freebet IDR 138 dengan rollover 1x di Slot Kasino.</li>
<li>Bonus akan diberikan di Slot Kasino setelah verifikasi berhasil.</li>
<li>Bonus freebet harus melalui rollover 1x di Slot Kasino dan minimum deposit IDR 50 sebelum melakukan penarikan kemenangan. Penarikan maksimum IDR 500.</li>
<li>Rollover bonus harus dipenuhi dalam waktu 7 hari untuk mencegah hangusnya bonus dan jumlah kemenangan.</li>
<li>Hanya permainan slot kasino yang akan diperhitungkan dalam kontribusi taruhan. <a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/gameexclusion_list.id-ID" target="_blank">Klik Disini</a> untuk melihat daftar game yang Disertakan dan Dikecualikan.</li>
<li>Bonus tidak dapat digunakan bersamaan dengan promosi M88 Mansion lainnya. Kecuali ada keterangan lebih lanjut.</li>
<li>Bonus ini hanya dapat diklaim 1x selama masa promosi.</li>
<li>Penarikan tidak akan diproses jika Anda masih memiliki rollover aktif. Silakan menghubungi Layanan Pelanggan (CS) untuk bantuan lebih lanjut.</li>
<li>M88 Mansion berhak mengubah, memperbarui, memodifikasi, atau membatalkan promosi ini kapan saja.</li>
<li><a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.id-ID" target="_blank">Syarat & Ketentuan Umum Promosi berlaku.</a></li>
`;

const tncTH = /*html*/ `
<li>โปรโมชั่นนี้สามารถใช้ได้กับสมาชิกใหม่ M88 Mansion 500 บาท ที่สมัครตั้งแต่ 23 พฤษภาคม 2567 เวลา 00:00:00 น. ถึง 31 พฤษภาคม 2567 เวลา 23:59:00 น. (GMT+8)</li>
<li>สมาชิกใหม่มีสิทธิ์รับโบนัสฟรีเบท 280 บาท โดยโบนัสมียอดเดิมพันหมุนเวียน 1 เท่า ในคาสิโนสล็อต</li>
<li>โบนัสจะปรับให้ในคาสิโนสล็อต เมื่อมีการยืนยันการฝากเงินขั้นต่ำที่สำเร็จ</li>
<li>จำนวนเงินฝาก + โบนัสจะต้องทำยอดเดิมพันหมุนเวียน 1 เท่า ในคาสิโนสล็อตก่อนที่จะถอนเงินรางวัล</li>
<li>โบนัสจะต้องทำยอดเดิมพันหมุนเวียนภายใน 7 วันเพื่อป้องกันการริบโบนัสและจำนวนเงินที่ชนะ</li>
<li>เฉพาะเกมคาสิโนสล็อตเท่านั้นที่จะนับรวมในการเดิมพันหมุนเวียน <a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/gameexclusion_list.th-TH" target="_blank">คลิกที่นี่</a> เพื่อดูรายชื่อเกมที่เข้าร่วมและไม่ร่วม</li>
<li>โบนัสนี้ไม่สามารถใช้ร่วมกับโปรโมชั่นและโบนัสอื่นๆ ของ M88 Mansion ได้ เว้นแต่จะระบุไว้</li>
<li>โบนัสนี้สามารถรับได้เพียง 1 ครั้งในช่วงระยะเวลาโปรโมชั่น</li>
<li>จะไม่สามารถดำเนินการถอนเงินได้ หากยอดหมุนเวียนยังไม่ผ่านเงื่อนไขที่กำหนด สมาชิกสามารถติดต่อฝ่ายประชาสัมพันธ์ลูกค้า เพื่อแจ้งดำเนินการยกเลิกยอดหมุนเวียนเดิมพันที่กำหนดได้</li>
<li>M88 Mansion ขอสงวนสิทธิ์ในการเปลี่ยนแปลงปรับปรุงแก้ไข หรือยกเลิกโปรโมชั่นนี้ได้ตลอดเวลา</li>
<li><a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.th-TH" target="_blank">ข้อตกลงทั่วไปและเงื่อนไขการใช้งานโปรโมชั่น</a></li>
`;

const tncVN = /*html*/ `
<li>Khuyến mãi áp dụng cho 500 thành viên mới M88 Mansion từ ngày 23/05/2024 lúc 00:00:00 đến ngày 31/05/2024 lúc 23:59:00 (GMT+8). </li>
<li>Thành viên mới hợp lệ nhận Thưởng Freebet 188 VND với 1x vòng cược tại Casino Slots. </li>
<li>Thưởng sẽ được cập nhật tại Casino Slots sau khi xác nhận khoản gửi tiền đầu tiên là 200 VND thành công. </li>
<li>Tiền thưởng cần trải qua 1x vòng cược tại Casino Slots và có khoảng tiền gửi tối thiểu là 200 VND trước
khi yêu cầu rút tiền thắng. Thành viên được rút tối đa là 2000 VND. </li>
<li>Số vòng cược cần hoàn tất trong vòng 7 ngày để tránh bị thu hồi tiền thưởng và tiền thắng.</li>
<li>Chỉ các trò chơi tại Casino slot game mới được tính vào số vòng cược yêu cầu. Nhấp <a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/gameexclusion_list.vi-VN" target="_blank">vào đây</a> để xem danh sách cược ngoại lệ và hợp lệ.</li>
<li>Khuyến mãi này không được kết hợp với các khuyến mãi khác trên trang M88 Mansion. Trừ khi có quy định khác. </li>
<li>Tiền thưởng chỉ được nhận 01 lần trong thời gian diễn ra khuyến mãi.</li>
<li>Thành viên không thể rút tiền nếu chưa hoàn tất yêu cầu vòng cược. Vui lòng liên hệ bộ phận Chăm sóc Khách Hàng để được hỗ trợ.</li>
<li>M88 Mansion có quyền thay đổi, cập nhật, điều chỉnh hoặc hủy khuyến mãi bất cứ lúc nào.</li>
<li><a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.vi-VN" target="_blank">Các quy định chung của chương trình khuyến mãi được áp dụng.</a></li>
`;

const tncCN = /*html*/ `
<li>活动期间：2024年5月23日至5月31日，期间内新注册的明陞M88玩家。</li>
<li>新玩家可于《老虎机》游戏中获得免费投注奖金58人民币（1倍流水）。</li>
<li>系统验证完成后，将自动发放于《老虎机》钱包中。</li>
<li>提款前请先完成最低首存100人民币，存款加彩金于《老虎机》游戏中达成 1倍流水，最高提款金额1000人民币。</li>
<li>奖金为收到后7天内有效，请于效期内达成指定投注额，逾期系统自动取消奖金与盈利。</li>
<li>本活动流水计算仅累计《老虎机》游戏，其余游戏将无法累计。<a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/gameexclusion_list.zh-CN" target="_blank">查看</a> 包含和排除游戏列表</li>
<li>本活动不能与明陞M88其他活动同时进行，除非活动有另外加注说明。</li>
<li>活动期间内，每位玩家仅可领取一次活动奖金。</li>
<li>如果您的账户仍有未完成的有效流水要求，您将无法提款。请联系在线客服办理撤除/取消/豁免流水要求即可。</li>
<li>明陞M88保留随时更改、更新、修改或取消此促销活动的权利。</li>
<li><a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.zh-CN" target="_blank">一般条款及规则应用于此优惠。</a></li>
`;

const tncMYCN = /*html*/ `
<li>活动期间：2024年5月23日至5月31日，期间内新注册的明陞M88玩家。</li>
<li>新玩家可于《老虎机》游戏中获得 38马币免费投注奖金（1倍流水）。</li>
<li>系统验证完成后，将自动发放于《老虎机》钱包中。</li>
<li>提款前请先完成最低首存100人民币，存款加彩金于《老虎机》游戏中达成 1倍流水，最高提款金额1000人民币。</li>
<li>奖金为收到后7天内有效，请于效期内达成指定投注额，逾期系统自动取消奖金与盈利。</li>
<li>本活动流水计算仅累计《老虎机》游戏，其余游戏将无法累计。<a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/gameexclusion_list.zh-CN" target="_blank">查看</a> 包含和排除游戏列表</li>
<li>本活动不能与明陞M88其他活动同时进行，除非活动有另外加注说明。</li>
<li>活动期间内，每位玩家仅可领取一次活动奖金。</li>
<li>如果您的账户仍有未完成的有效流水要求，您将无法提款。请联系在线客服办理撤除/取消/豁免流水要求即可。</li>
<li>明陞M88保留随时更改、更新、修改或取消此促销活动的权利。</li>
<li><a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.zh-CN" target="_blank">一般条款及规则应用于此优惠。</a></li>
`;

const tncJPY = /*html*/ `
<li>本プロモーションは、2024年5月23日01:00:00～2024年6月1日00:59:00（日本時間 ）プロモーション期間中に日本国（USD）から新規登録した先着500名様に適応されます。</li>
<li>新規登録メンバーは、カジノでプレイができる、ロールオーバー条件1倍付きのフリーベットUSD 8を獲得できます。</li>
<li>新規登録後ボーナスはカジノで付与されます。</li>
<li>勝利金出金の条件として、入金額＋ボーナスをカジノで1倍のロールオーバーを満たし、最低でも USD10を入金する必要があります。最高出金額は USD 100までとなります。</li>
<li>ロールオーバー期限は、ボーナスが付与されてから7日間です。期限内にロールオーバーを達成できなかった場合、ボーナスとその勝利金は没収となります。</li>
<li>カジノスロット専用ボーナスでは、カジノスロットのみが、ロールオーバー条件にカウントされます。こちらをクリックして除外ゲームを確認してください。</li>
<li>特に記載がない限り、本ボーナスはM88 Mansionの他のプロモーションと併用することはできません。</li>
<li>本ボーナスは、プロモ期間中1回のみ請求可能です。</li>
<li>進行中のロールオーバーがある場合は出金は処理されません。ロールオーバーの免除をご希望の場合は、カスタマーサポートまでお問い合わせください。</li>
<li>M88 Mansion は、いつでもプロモーションを変更、更新、修正、中止する権利を有します。</li>
<li><a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.ja-JP" target="_blank">プロモーションの一般利用規約が適用されます。</a></li>
`;

const tncKRW = /*html*/ `
<li>본 프로모션은 2024년 5월 23일 01:00:00 부터 2024년 6월 1일 00:59:59 까지 M88 맨션에 신규 가입을 진행한 선착순 500명의 회원을 대상으로 진행됩니다.</li>
<li>신규 회원은 KRW 10,888의 프리벳 보너스를 획득할 수 있습니다. 프리벳 보너스는 슬롯에서 1배 롤오버를 충족하여야 합니다.</li>
<li>회원 가입 인증을 완료한 회원의 슬롯 지갑으로 보너스가 지급됩니다.</li>
<li>보너스는 슬롯에서 1배 롤오버 충족 및 KRW 10,000이상 입금을 완료한 후 출금할 수 있습니다. 본 보너스의 최대 지급 금액은 KRW 100,000입니다.</li>
<li>롤오버 조건은 보너스 금액이 지급된 후 7일 이내에 충족되어야 합니다. 그렇지 않을 경우 보너스 및 당첨금이 취소됩니다.</li>
<li>슬롯 게임만 롤오버에 충족됩니다. 보너스 롤링 제외 게임 목록은 <a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/gameexclusion_list.ko-KR" target="_blank">여기</a> 를 클릭해 확인 가능합니다.</li>
<li>본 보너스는 달리 명시되지 않는 한 M88 맨션의 타 보너스와 중복 신청이 불가능합니다.</li>
<li>보너스는 한 번만 획득할 수 있으며 프로모션 기간 동안에만 유효합니다.</li>
<li>롤오버가 충족되지 않으면 출금은 불가능합니다. 더 자세한 문의 사항은 라이브챗으로 문의하시기 바랍니다.</li>
<li>M88 맨션은 언제든 이 프로모션을 변경 혹은 취소할 수 있습니다.</li>
<li><a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.ko-KR" target="_blank">프로모션 이용약관이 적용됩니다.</a></li>
`;

const tncIN = /*html*/ `
`;
