
const tncEN = /*html*/`
`;

const tncID = /*html*/`
<li>Promosi ini berlaku untuk 300 Member baru M88 Mansion selama periode 1 Maret 2024 00:00:00 hingga 15 April 2024 23:59:00 (GMT+8).</li>
<li>Member baru harus memilih Opt-in setelah pendaftaran berhasil.</li>
<li>Member baru berhak mendapatkan Freebet IDR 88 dengan rollover 10x di permainan Pragmatic Play: Gates of Olympus.
    <table>
        <thead>
            <tr>
                <th>PERMAINAN</th>
                <th>TIPE BONUS</th>
                <th>MIN DEPOSIT PERTAMA</th>
                <th>MAX BONUS </th>
                <th>RO<br>(DEPOSIT+BONUS)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Slots - Gates Of Olympus</td>
                <td>FREEBET</td>
                <td>-</td>
                <td>IDR 88</td>
                <td>10x</td>
            </tr>
        </tbody>
    </table>
</li>
<li>Untuk Bonus Freebet, hanya Gates of Olympus dari Pragmatic Play yang masuk dalam syarat rollover.</li>
<li>Rollover harus dipenuhi dalam waktu 10 hari untuk mencegah pembatalan bonus dan jumlah kemenangan.</li>
<li>Member baru harus melakukan deposit sebesar IDR 100 sebelum penarikan dapat dilakukan.</li>
<li>Bonus tidak dapat digunakan bersamaan dengan promosi M88 Mansion lainnya. Kecuali ada keterangan lebih lanjut.</li>
<li>Bonus hanya dapat diklaim 1x selama periode promosi.</li>
<li>Penarikan akan diproses setelah mencapai persyaratan rollover. Jika anda memiliki pertanyaan, silakan hubungi Layanan Pelanggan (CS).</li>
<li>M88 Mansion berhak mengubah, memperbarui, memodifikasi, atau membatalkan promosi ini kapan saja.</li>
<li><a class="tc--link" href="https://www.m88.com/~/static/standalone-pages/promotions/terms-conditions.id-ID" target="_blank">Syarat & Ketentuan Umum Promosi berlaku</a>.</li>
`;

const tncTH = /*html*/`
`;

const tncVN = /*html*/`
`;

const tncCN = /*html*/`
`;

const tncMYCN = /*html*/`
`;