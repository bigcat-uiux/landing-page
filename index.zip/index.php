<?php include 'temps/head.php'; ?>
<?php include 'temps/header.php'; ?>
	
	<main class="content">

		<?php include 'temps/content-banner.php'; ?>
    <?php //include 'temps/content-steps.php'; ?>
    <?php //include 'temps/content-tiles.php'; ?>
    <?php //include 'temps/content-slider.php'; ?>
		<?php //include 'temps/content-m88.php'; ?>
    <?php //include 'temps/content-bottom.php'; ?>
    <?php //include 'temps/content-teaser.php'; ?>

	</main>

<?php include 'temps/footer.php'; ?>