<?php include 'temps/head.php'; ?>
<?php include 'temps/header.php'; ?>

<main class="content">

  <?php  // include 'temps/content-banner.php'; ?>

  <?php include 'temps/form-betid.php'; ?>
</main>

<?php // include 'temps/footer-tnc.php'; ?>
<?php include 'temps/footer.php'; ?>
<?php // include 'entries.php'; ?>
<?php include 'temps/modals.php'; ?>