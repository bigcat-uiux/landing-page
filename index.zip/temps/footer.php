  <footer class="footer">

    <?php include 'temps/footer-tnc.php'; ?>
    <?php include 'temps/footer-totop.php'; ?>  
    <?php include 'temps/footer-social.php'; ?>  
    <?php include 'temps/footer-partners.php'; ?>  
    <?php include 'temps/footer-copy.php'; ?> 

  </footer>

  <script type="text/javascript" src="assets/js/scripts.js"></script>
  <script type="text/javascript" src="assets/js/langcontent/tnc.js"></script>

</body>
</html>