<section class="content__teaser">

  <div class="content__teaser__banner">
    <div class="inner">

      <div class="content__teaser__banner__left">
        <h1 data-txt="txt1"></h1>
        <h2 data-txt="txt2-teaser"></h2>
      </div>
      <!-- <a class="btn btn--gold desk" data-txt="claim-now" href="<?php echo $config[$url]['aff_link']; ?>"></a> -->
      <!-- <a class="btn btn--gold mobi" data-txt="claim" href=""></a> -->

    </div>
  </div>

</section>