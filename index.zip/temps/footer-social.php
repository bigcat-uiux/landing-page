<section class="social">
  <div class="inner">
    <!-- <a data-cta="facebook" target="_blank" class="social__media"><i class="social__media__icon social__media__icon--facebook"></i></a> -->
    <!-- <a data-cta="instagram" target="_blank" class="social__media"><i class="social__media__icon social__media__icon--instagram"></i></a> -->
    <a data-cta="twitter" target="_blank" class="social__media"><i class="social__media__icon social__media__icon--twitter"></i></a>
    <a data-cta="youtube" target="_blank" class="social__media"><i class="social__media__icon social__media__icon--youtube"></i></a>
    <!-- <a data-cta="tiktok" target="_blank" class="social__media"><i class="social__media__icon social__media__icon--tiktok"></i></a> -->
  </div>
</section>