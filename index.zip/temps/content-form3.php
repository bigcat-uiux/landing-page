<form id="minigameForm3" name="minigameForm3" class="minigame-form minigame-form--3" method="post">

  <div class="minigame-form__group  minigame-form__group--3">

    <input name="minigameMg3" id="minigameMg3" value="WordSearchPuzzles" style="display: none">

    <div class="minigame-form__group__field">
      <label data-label="label-m88username">&nbsp;</label>
      <input type="text" id="m88usernameMg3" name="m88usernameMg3" value="" required data-placeholder="pholder-m88username">
    </div>
    <div class="minigame-form__group__field">
      <label data-label="label-answer1c">&nbsp;</label>
      <input type="text" id="answer1Mg3" name="answer1Mg3" value="" required data-placeholder="pholder-answer">
    </div>

  </div>

  <p class="participated"><span class="icn icn--success"></span> <span data-txt="participated">&nbsp;</span></p>

  <button type="submit" id="submitMinigame3" name="submitMinigame3" data-txt="submit" class="btn btn--gold btn--submit deact" data-value="form-register">&nbsp;</button>

  <p class="submitting" data-txt="submitting">&nbsp;</p>

</form>
