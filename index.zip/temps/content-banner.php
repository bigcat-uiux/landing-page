<section class="content__banner">
  <div class="inner">

    <div class="content__banner__texts">
      <div class="text">
      <h1 data-txt="txt1"></h1>
      <!-- <h2 data-txt="txt2"></h2> -->
      <a class="btn btn--gold" data-txt="claim-now-default" href="<?php echo $config[$url]['aff_link']; ?>"></a>
      </div>
      <!-- <a class="btn btn--gold" data-txt="claim-now-msports" href="<?php echo $config[$url]['aff_link_msports']; ?>"></a>
      <a class="btn btn--gold" data-txt="claim-now-casino" href="<?php echo $config[$url]['aff_link_casino']; ?>"></a>
      <a class="btn btn--gold" data-txt="claim-now-live" href="<?php echo $config[$url]['aff_link_live']; ?>"></a> -->
    </div>
  </div>
</section>