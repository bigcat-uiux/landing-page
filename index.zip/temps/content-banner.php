<section class="content__banner">
  <div class="inner">

    <div class="content__banner__texts">
      <h1 data-txt="txt1"></h1>
      <h2 data-txt="txt2"></h2>
      <a class="btn btn--gold" data-txt="claim-now" href="<?php echo $config[$url]['aff_link']; ?>"></a>
      <!-- <a class="btn btn--gold" data-txt="claim-now-msports" data-cta="cta-msports"></a> -->
			<!-- <a class="btn btn--gold no--id" data-txt="claim-now-casino" data-cta="cta-hcasino"></a> -->
    </div>

    <div class="content__banner__tnc">
      <h4 class="content__banner__tnc__head" data-txt="tnc"></h4>
    </div>

  </div>
</section>