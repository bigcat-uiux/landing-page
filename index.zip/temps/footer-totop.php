<section class="to-top">
  <div class="inner">
    <button class="btn btn--hollow btn-back-top" data-txt="to-top"></button>

    <hr>
  </div>
</section>