<section class="copy">
  <div class="inner">

    <div class="copy__responsible">
      <p data-txt="ftxt6"></p>
      <div class="copy__responsible__licenses">
        <img src="assets/images/icons/icon-vanuatu.svg">
        <img src="assets/images/icons/icon-ga.svg">
        <img src="assets/images/icons/icon-itech.svg">
        <img src="assets/images/icons/icon-18plus.svg">
        <p>M88.com 
          <script>
            var today = new Date();
            document.write(today.getFullYear());
          </script>
        </p>
      </div>
    </div>

    <p data-txt="ftxt7"></p>
    <p data-txt="ftxt8"></p>

  </div>
</section>