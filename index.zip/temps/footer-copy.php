<section class="copy">
  <div class="inner">

  </div>
  
    <div class="copy__responsible">
      <div href="https://m88.com" target="_blank" title="M88 | LaLiga" class="logo-copy" data-txt="link-logo-bottom"></div>
        <p>© M88.com Global Partners
          <script>
            var today = new Date();
            document.write(today.getFullYear());
          </script>
        </p>
      </div>
    </div>
</section>