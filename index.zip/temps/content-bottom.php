<section class="content__bottom">
  <div class="inner">

    <h2 class="head-line" data-txt="bottom-head"></h2>
    <p data-txt="bottom-txt1"></p>

    <h3 data-txt="bottom-head-sub1"></h3>
    <p data-txt="bottom-txt2"></p>

    <h3 data-txt="bottom-head-sub2"></h3>
    <p data-txt="bottom-txt3"></p>

  </div>
</section>