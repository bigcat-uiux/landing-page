<section class="content__bottom">
  <div class="inner">

    <h2 class="head-line" data-txt="bottom-head">&nbsp;</h2>
    <p data-txt="bottom-txt1">&nbsp;</p>

    <h3 data-txt="bottom-head-sub1">&nbsp;</h3>
    <p data-txt="bottom-txt2">&nbsp;</p>

    <h3 data-txt="bottom-head-sub2">&nbsp;</h3>
    <p data-txt="bottom-txt3">&nbsp;</p>

  </div>
</section>