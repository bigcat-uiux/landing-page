<form id="minigameForm1" name="minigameForm1" class="minigame-form minigame-form--1" action="" method="post">

  <div class="minigame-form__group minigame-form__group--1">

    <input name="timestamp" id="timestamp1" style="display:none">
    <input name="minigame" id="minigame" value="TraditionalLanternFestivalRiddles" style="display:none">

    <div class="minigame-form__group__field">
      <label data-label="label-m88username">&nbsp;</label>
      <input type="text" id="m88username" name="m88username" value="" required data-placeholder="pholder-m88username">
    </div>
    <div class="minigame-form__group__field">
      <label data-label="label-answer1a">&nbsp;</label>
      <input type="text" id="answer1" name="answer1" value="" required data-placeholder="pholder-answer">
    </div>
    <div class="minigame-form__group__field">
      <label data-label="label-answer2a">&nbsp;</label>
      <input type="text" id="answer2" name="answer2" value="" required data-placeholder="pholder-answer">
    </div>
    <div class="minigame-form__group__field">
      <label data-label="label-answer3a">&nbsp;</label>
      <input type="text" id="answer3" name="answer3" value="" required data-placeholder="pholder-answer">
    </div>

  </div>

  <p class="participated"><span class="icn icn--success"></span> <span data-txt="participated">&nbsp;</span></p>

  <button type="submit" id="submitMinigame1" name="submitMinigame1" data-txt="submit" class="btn btn--gold btn--submit" data-value="form-register">&nbsp;</button>

  <p class="submitting" data-txt="submitting">&nbsp;</p>

</form>

<form id="minigameForm2" name="minigameForm2" class="minigame-form minigame-form--2" method="post">

  <div class="minigame-form__group  minigame-form__group--2">

    <input name="timestamp" id="timestamp2" style="display:none">
    <input name="minigame" id="minigame" value="FindLanternRabbit" style="display:none">

    <div class="minigame-form__group__field">
      <label data-label="label-m88username">&nbsp;</label>
      <input type="text" id="m88username" name="m88username" value="" required data-placeholder="pholder-m88username">
    </div>
    <div class="minigame-form__group__field">
      <label data-label="label-answer1b">&nbsp;</label>
      <input type="text" id="answer1" name="answer1" value="" required data-placeholder="pholder-answer">
    </div>
    <div class="minigame-form__group__field">
      <label data-label="label-answer2b">&nbsp;</label>
      <input type="text" id="answer2" name="answer2" value="" required data-placeholder="pholder-answer">
    </div>

    <input type="text" id="answer3" name="answer3" value="" style="display: none">

  </div>

  <p class="participated"><span class="icn icn--success"></span> <span data-txt="participated">&nbsp;</span></p>

  <button type="submit" id="submitMinigame2" name="submitMinigame2" data-txt="submit" class="btn btn--gold btn--submit" data-value="form-register">&nbsp;</button>

  <p class="submitting" data-txt="submitting">&nbsp;</p>

</form>

<form id="minigameForm3" name="minigameForm3" class="minigame-form minigame-form--3" method="post">

  <div class="minigame-form__group  minigame-form__group--3">

    <input name="timestamp" id="timestamp3" style="display:none">
    <input name="minigame" id="minigame" value="WordSearchPuzzles" style="display: none">

    <div class="minigame-form__group__field">
      <label data-label="label-m88username">&nbsp;</label>
      <input type="text" id="m88username" name="m88username" value="" required data-placeholder="pholder-m88username">
    </div>
    <div class="minigame-form__group__field">
      <label data-label="label-answer1c">&nbsp;</label>
      <input type="text" id="answer1" name="answer1" value="" required data-placeholder="pholder-answer">
    </div>

    <input type="text" id="answer2" name="answer2" value="" style="display: none">
    <input type="text" id="answer3" name="answer3" value="" style="display: none">

  </div>

  <p class="participated"><span class="icn icn--success"></span> <span data-txt="participated">&nbsp;</span></p>

  <button type="submit" id="submitMinigame3" name="submitMinigame3" data-txt="submit" class="btn btn--gold btn--submit" data-value="form-register">&nbsp;</button>

  <p class="submitting" data-txt="submitting">&nbsp;</p>

</form>
