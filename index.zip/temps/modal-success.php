<div class="modals__lbox modals__lbox--success">
	<div class="bar mobi"></div>
	<div class="modals__lbox__head">
		<h4 data-txt="success-head">&nbsp;</h4>
		<div class="modals__lbox__close"></div>
	</div>
	<div class="modals__lbox__content">
		<img class="modals__lbox__content__ok" src="./assets/images/modals/big-success.svg" width="96" height="96" alt="">
		<h4 data-txt="success-content-head"></h4>

		<!-- <p data-txt="success-msg"></p> -->

	</div>
  <div class="modals__lbox__foot">
			<!--<button class="btn btn--modal btn--modal--clear toR16" data-txt="btn-next"></button>-->
			<button class="btn btn--modal btn--gold" data-txt="btn-ok"></button>
		</div>
</div>