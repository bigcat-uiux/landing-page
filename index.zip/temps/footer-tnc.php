<section class="tnc">
  <div class="inner">

    <h4 class="tnc__head" data-txt="tnc-betid">&nbsp;</h4>
    <ol class="tnc__content">&nbsp;</ol>

  </div>
</section>