<section class="tnc">
  <div class="inner">

    <h4 class="tnc__head" data-txt="tnc2"></h4>
    <ol class="tnc__content"></ol>

  </div>
</section>