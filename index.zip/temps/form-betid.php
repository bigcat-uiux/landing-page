<section class="form form--betid">
  <div class="inner">
    <?php include 'content-form-betid.php'; ?>
  </div>
</section>