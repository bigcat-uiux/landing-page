<!DOCTYPE html>
<html lang="en">
<head>
<?php 
    $url = $_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF'];
    // echo $url;
    $config = [
      'localhost/1236/getbonus1/index.php' => [
        'ga_code' => '',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/1/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
      'clubthreesix.com/spens/getbonus1/index.php' => [
        'ga_code' => '',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/1/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
      'clubthreesix.com/spens/getbonus2/index.php' => [
        'ga_code' => 'G-FT0S4596YF',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/2/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
      'clubthreesix.com/spens/getbonus3/index.php' => [
        'ga_code' => 'G-J9B7Y08V6L',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/3/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
      'clubthreesix.com/spens/getbonus4/index.php' => [
        'ga_code' => 'G-QYTVT3E0HS',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/4/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
      'clubthreesix.com/spens/getbonus5/index.php' => [
        'ga_code' => 'G-34KLP0HWG5',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/5/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
      'clubthreesix.com/spens/getbonus6/index.php' => [
        'ga_code' => 'G-2EY3VHP5V0',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/6/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
      'clubthreesix.com/spens/getbonus7/index.php' => [
        'ga_code' => 'G-JJ9F3JM3KE',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/7/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
      'clubthreesix.com/spens/getbonus8/index.php' => [
        'ga_code' => 'G-M0RX65WEYD',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/8/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
			'getbonus1.com/index.php' => [
        'ga_code' => 'G-NSN0HFE40Z',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/1/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
      'getbonus2.com/index.php' => [
        'ga_code' => 'G-FT0S4596YF',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/2/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
			'getbonus3.com/index.php' => [
        'ga_code' => 'G-J9B7Y08V6L',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/3/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
      'getbonus4.com/index.php' => [
        'ga_code' => 'G-QYTVT3E0HS',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/4/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
      'getbonus5.com/index.php' => [
        'ga_code' => 'G-34KLP0HWG5',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/5/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
      'getbonus6.com/index.php' => [
        'ga_code' => 'G-2EY3VHP5V0',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/6/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
      'getbonus7.com/index.php' => [
        'ga_code' => 'G-JJ9F3JM3KE',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/7/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
      'getbonus8.com/index.php' => [
        'ga_code' => 'G-M0RX65WEYD',
        'claim_now' => 'https://record.brave158.com/_tips0VFQrzslu5cdA8BczmNd7ZgqdRLk/8/',
        'sports_link' => '',
        'livecasino_link' => '',
        'casino_link' => '',
        'knlt_link' => ''
      ],
    ];
  ?>

  <!-- Google tag (gtag.js) -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $config[$url]['ga_code']; ?>"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', '<?php echo $config[$url]['ga_code']; ?>');
  </script>
	<title data-txt="title"></title>
	<meta charset="utf-8" />
	<meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport" />

	<link rel="shortcut icon" href="assets/images/favicon-16x16.png" type="image/x-icon">

	<link rel="stylesheet" href="assets/css/swiper-bundle.min.css" />
	<link rel="stylesheet" href="assets/css/style.css" />
	<link rel="stylesheet" href="assets/css/misc.css" />

	<script type="text/javascript" src="assets/js/jquery-3.6.0.min.js"></script>
	<script type="text/javascript" src="assets/js/jquery-migrate-3.3.2.min.js"></script>
	<script type="text/javascript" src="assets/js/swiper-bundle.min.js"></script>

</head>
<body class="registered">